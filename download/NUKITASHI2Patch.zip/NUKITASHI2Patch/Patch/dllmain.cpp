﻿// dllmain.cpp : 定义 DLL 应用程序的入口点。

//必要头
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
//文件流
#include <iostream>
#include <shlobj_core.h>
//Hook库
#include "detours.h"

//------配置参数------------
//每个需要hook的点位
//函数入口指针
static PVOID p_getRes = (PVOID)(0x400000+0x5940); //资源读取函数入口
typedef BYTE* (__cdecl* Func_GetRes)(char* fileName, DWORD* fileSize); //定义相应的函数格式
//解包的输出文件夹路径
const wchar_t* dumpdir = L"C:\\Users\\Use\\Downloads\\NUKITASHI2Patch\\Release\\dump\\";

//------代码简化模板------
void setHook(PVOID& hookAddress, PVOID detourFunction)
{
    DetourTransactionBegin();
    DetourUpdateThread(GetCurrentThread());
    DetourAttach(&hookAddress, detourFunction);
    DetourTransactionCommit();
}
void setHookToCode(PVOID& hookAddress, PVOID detourFunction, PVOID& nextCodeAddress, int offset)
{
    PDETOUR_TRAMPOLINE pTrampoline;
    DetourTransactionBegin();
    DetourUpdateThread(GetCurrentThread());
    DetourAttachEx(&hookAddress, detourFunction, &pTrampoline, NULL, NULL);
    DetourTransactionCommit();
    nextCodeAddress = (PVOID)((DWORD)pTrampoline + offset);
}

//------替换字体的hook------
static auto fontNew = "黑体";
static DWORD fontCharSet = 0x84;
static PVOID pFontNext;
_declspec(naked) void setFontDetour()
{
    _asm
    {
        //替换字体
        push fontNew
        mov edx, dword ptr ds : [esi + 0x30]
        push ecx
        mov ecx, dword ptr ds : [esi + 0x2C]
        push edx
        mov edx, dword ptr ds : [esi + 0x28]
        push 0
        push 0
        //替换编码
        push fontCharSet
        mov ecx, dword ptr ds : [esi + 0x24]
        push edx
        mov edx, dword ptr ds : [esi + 0x20]
        push ecx
        mov ecx, dword ptr ds : [esi + 0x1C]
        push edx
        mov edx, dword ptr ds : [esi + 0x18]
        push ecx
        mov ecx, dword ptr ds : [esi + 0x14]
        push edx
        mov edx, dword ptr ds : [esi + 0x10]
        push ecx
        //0 edx
        push 0
        //0x2c->0x20 or 0x10->0xA eax
        //分支赋值
        cmp eax, 0x10
        je A1
        push 0x20
        jmp pFontNext
    A1:
        push 10
        jmp pFontNext
    }
}
void setFontHook()
{
    PVOID pFontAdd = (PVOID)(0x438263);
    setHook(pFontAdd, setFontDetour);
    //直接到Call CreateFont的地方，计算可得此处最多Detour了5个字节，所以+43地方未被替换
    pFontNext = (PVOID)(0x43828E);
}
//必要的跳过边界检测方案
void PatchWrite(LPVOID lpAddr, BYTE&& lpBuf)
{
    DWORD dwProtect;
    DWORD nSize = sizeof(BYTE);
    if (VirtualProtect(lpAddr, nSize, PAGE_EXECUTE_READWRITE, &dwProtect))
    {
        CopyMemory(lpAddr, &lpBuf, nSize);
        VirtualProtect(lpAddr, nSize, dwProtect, &dwProtect);
    }
}
void setCharCheckPatch()
{
    PatchWrite((PVOID)(0x00429D15 + 2), (BYTE)0x81); // c >= 0x81
    PatchWrite((PVOID)(0x00429D1A + 2), (BYTE)0xFE); // c <= 0x9F
    PatchWrite((PVOID)(0x00429D1F + 2), (BYTE)0x81); // c >= 0xE0
    PatchWrite((PVOID)(0x00429D24 + 2), (BYTE)0xFE); // c <= 0xFC

    PatchWrite((PVOID)(0x0043ABDF + 2), (BYTE)0x81); // c >= 0x81
    PatchWrite((PVOID)(0x0043ABE4 + 2), (BYTE)0xFE); // c <= 0x9F
    PatchWrite((PVOID)(0x0043ABE9 + 2), (BYTE)0x81); // c >= 0xE0
    PatchWrite((PVOID)(0x0043ABEE + 2), (BYTE)0xFE); // c <= 0xFC

    PatchWrite((PVOID)(0x0043ADCE + 1), (BYTE)0x81); // c >= 0x81
    PatchWrite((PVOID)(0x0043ADD2 + 1), (BYTE)0xFE); // c <= 0x9F
    PatchWrite((PVOID)(0x0043ADD6 + 1), (BYTE)0x81); // c >= 0xE0
    PatchWrite((PVOID)(0x0043ADDA + 1), (BYTE)0xFE); // c <= 0xFC

    PatchWrite((PVOID)(0x0043BDCD + 2), (BYTE)0x81); // c >= 0x81
    PatchWrite((PVOID)(0x0043BDD2 + 2), (BYTE)0xFE); // c <= 0x9F
    PatchWrite((PVOID)(0x0043BDD7 + 2), (BYTE)0x81); // c >= 0xE0
    PatchWrite((PVOID)(0x0043BDDC + 2), (BYTE)0xFE); // c <= 0xFC
}

//------注册表读写hook------
//两种编码的注册表内容
static auto gszRegPathGBK = "\x73\x6F\x66\x74\x77\x61\x72\x65\x5C\x51\x72\x75\x70\x70\x6F\x5C\x92\x69\xA4\xAD\xA5\xB2\xA9\x60\xA4\xDF\xA4\xBF\xA4\xA4\xA4\xCA\x8D\x75\xA4\xCB\xD7\xA1\xA4\xF3\xA4\xC7\xA4\xEB\xD8\x9A\xC8\xE9\xA4\xCF\xA4\xC9\xA4\xA6\xA4\xB9\xA4\xEA\xA4\xE3\xA4\xA4\xA4\xA4\xA4\xC7\xA4\xB9\xA4\xAB\xA3\xBF\xA3\xB2";
static PVOID pCopyRegistryPathNextAddr1;
_declspec(naked) void CopyRegistryPathDetour1()
{
    _asm
    {
        PUSH    gszRegPathGBK
        JMP     pCopyRegistryPathNextAddr1
    }
}
static PVOID pCopyRegistryPathNextAddr2;
_declspec(naked) void CopyRegistryPathDetour2()
{
    _asm
    {
        PUSH    gszRegPathGBK
        JMP     pCopyRegistryPathNextAddr2
    }
}
void setRegistryHook()
{
    //hook传入的参数
    PVOID pCopyRegistryPathAddr1 = (PVOID)(0x4082CB);
    //此处的push指令只有1字节
    setHookToCode(pCopyRegistryPathAddr1, CopyRegistryPathDetour1, pCopyRegistryPathNextAddr1, 1);
    //第二处同理
    PVOID pCopyRegistryPathAddr2 = (PVOID)(0x42AAE9);
    setHookToCode(pCopyRegistryPathAddr2, CopyRegistryPathDetour2, pCopyRegistryPathNextAddr2, 1);
}

//------替换部分资源的hook------
BYTE* replaceResDetourFun(char* filename, DWORD* filesize)
{
    //看一下替换文件是否存在
    FILE* fp;
    if (!fopen_s(&fp, (const char*)filename, "rb"))
    {
        if (fp)
        {
            //获取文件大小
            fseek(fp, 0, SEEK_END);
            auto size = ftell(fp);
            fseek(fp, 0, SEEK_SET);
            if (size > 0)
            {
                BYTE* ptr = new BYTE[size];
                if (ptr)
                {
                    if (fread(ptr, size, 1, fp) == 1)
                    {
                        fclose(fp);
                        //将大小保存在lpFileSize
                        *filesize = size;
                        //返回读取到的数据指针
                        return ptr;
                    }
                    delete[] ptr;
                }
            }
            fclose(fp);
        }
    }
    //执行原来的代码并返回
    return (Func_GetRes(p_getRes))(filename, filesize);
}
//------获取所有资源的hook------
void dumpFile(char* fileName)
{
    //存储文件大小和内容
    DWORD fileSize;
    BYTE* buf;
    //调用函数获取相应内容
    buf = (Func_GetRes(p_getRes))(fileName, &fileSize);

    //转化为输出路径 char* ->  wchar_t*
    //fileName变为wchar_t格式
    wchar_t fnmbuffer[256];
    size_t nu = strlen(fileName);
    size_t n = (size_t)MultiByteToWideChar(932, 0, fileName, int(nu), NULL, 0);
    memset(fnmbuffer, 0, sizeof(wchar_t) * 256);
    MultiByteToWideChar(932, 0, fileName, int(nu), fnmbuffer, int(n));
    //在wchar_t上拼接路径
    wchar_t filePath[256];
    wcscpy_s(filePath, dumpdir);
    wcscat_s(filePath, fnmbuffer);

    //创建文件的父目录
    wchar_t* p = wcsstr(fnmbuffer, L"\\");
    if (p != NULL)
    {
        wchar_t dirPath[256];
        wcscpy_s(dirPath, filePath);
        dirPath[wcslen(dirPath) - wcslen(p)] = 0;
        SHCreateDirectoryExW(NULL, dirPath, NULL);
    }
    //使用WindowAPI将数据写入文件(C/C++的原生文件IO流在Window上不好用)
    HANDLE pFile = CreateFile(filePath, GENERIC_WRITE, FILE_SHARE_WRITE, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    DWORD dwBytesWrite = 0;
    WriteFile(pFile, buf, fileSize, &dwBytesWrite, NULL);
    CloseHandle(pFile);
    //释放缓存数据
    free(buf);
}
BYTE* getResDetourFun(char* filename, DWORD* filesize)
{
    //执行钩子内容
    dumpFile(filename);
    //执行原来的代码并返回
    return (Func_GetRes(p_getRes))(filename, filesize);
}

//--------------------------
//------配置需要的钩子------
//--------------------------
void init()
{
    //获取所有资源的hook
    //setHook(p_getRes, getResDetourFun);
    //替换部分资源的hook
    setHook(p_getRes, replaceResDetourFun);
    //注册表读写hook
    setRegistryHook();

    //替换字体的hook
    setFontHook();
    //跳过边界检测
    setCharCheckPatch();
}
//日志功能，便于调试
static void make_console()
{
    if (!AllocConsole())
        MessageBox(NULL, L"The console window was not created", NULL, MB_ICONEXCLAMATION);

    FILE* fp;
    freopen_s(&fp, "CONIN$", "r", stdin);
    freopen_s(&fp, "CONOUT$", "w", stdout);
    //freopen_s(&fp, "C:\\Users\\Use\\Downloads\\NUKITASHI2Patch\\Release\\tmp.txt", "w", stdout);
    freopen_s(&fp, "CONOUT$", "w", stderr);

    std::cout << "Open Console Success!" << std::endl << std::flush;

    //fclose(fp);
}
//必要代码
BOOL APIENTRY DllMain(HMODULE hModule, DWORD  ul_reason_for_call, LPVOID lpReserved)
{
    switch (ul_reason_for_call)
    {
    case DLL_PROCESS_ATTACH:
        //日志
        //make_console();
        //初始化
        init();
    case DLL_THREAD_ATTACH:
    case DLL_THREAD_DETACH:
    case DLL_PROCESS_DETACH:
        break;
    }
    return TRUE;
}
//不加就运行不了的东西
extern "C" __declspec(dllexport) void dummy(void) {
    return;
}

