﻿#include <windows.h>
#include <iostream>

#include "detours.h"

int main()
{
    const wchar_t* cmd = L"C:\\Users\\Use\\Desktop\\Game\\Qruppo\\抜きゲーみたいな島に住んでる貧乳はどうすりゃいいですか？２\\NUKITASHI2.EXE";
    //const wchar_t* cur_dir = L"C:\\Users\\Use\\Desktop\\Game\\Qruppo\\抜きゲーみたいな島に住んでる貧乳はどうすりゃいいですか？２";
    const wchar_t* cur_dir = L"C:\\Users\\Use\\Downloads\\NUKITASHI2Patch\\Release\\";
    const char* dll_path = "C:\\Users\\Use\\Downloads\\NUKITASHI2Patch\\Release\\Patch.dll";

    wchar_t cmd_buf[1 << 10];
    wcscpy_s(cmd_buf, _countof(cmd_buf), cmd);

    STARTUPINFO si;
    PROCESS_INFORMATION pi;
    ZeroMemory(&si, sizeof(si));
    ZeroMemory(&pi, sizeof(pi));
    si.cb = sizeof(si);

    if (!DetourCreateProcessWithDllEx(NULL, cmd_buf,
        NULL, NULL, FALSE, 0,
        NULL, cur_dir, &si, &pi, dll_path, NULL))
    {
        std::cout << "creating process failed\n";
        return 0;
    }

    //CloseHandle(&si);
    //CloseHandle(&pi);

    return 0;
}
